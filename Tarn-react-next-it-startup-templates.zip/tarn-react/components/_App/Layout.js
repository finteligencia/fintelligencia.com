import React from 'react';
import Head from "next/head";
import GoTop from './GoTop';

// Layout

const Layout = ({ children }) => {
    return(
        <React.Fragment>
            <Head>
                <title>Tarn - React Next IT Startup Templates Collection</title>
                <meta name="description" content="Tarn - React Next IT Startup Templates Collection" />
                <meta name="og:title" property="og:title" content="Tarn - React Next IT Startup Templates Collection"></meta>
                <meta name="twitter:card" content="Tarn - React Next IT Startup Templates Collection"></meta>
                <link rel="canonical" href="https://tarn-react.envytheme.com/"></link>
                <meta property="og:image" content="https://res.cloudinary.com/dev-empty/image/upload/v1593069801/explore-learning.jpg" />
            </Head>

            {children}
        
            <GoTop scrollStepInPx="100" delayInMs="10.50" />
        </React.Fragment>
    );
}

export default Layout;